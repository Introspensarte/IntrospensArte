
export function calculateTraces(type: string, wordCount: number, responses?: number): number {
  switch (type.toLowerCase()) {
    case 'microcuento':
      if (wordCount >= 1 && wordCount <= 100) {
        return 100;
      }
      return 100; // Default para microcuento

    case 'drabble':
      if (wordCount >= 101 && wordCount <= 200) {
        return 200;
      }
      return 200; // Default para drabble

    case 'narrativa':
      if (wordCount >= 201) {
        if (wordCount <= 499) {
          return 300; // Base 201-499 palabras
        }
        // Calcular trazos adicionales por cada 500 palabras
        const baseTraces = 300;
        const extraWords = wordCount - 499;
        const extra500Blocks = Math.floor(extraWords / 500);
        return baseTraces + (extra500Blocks * 100);
      }
      return 300; // Default para narrativa

    case 'hilo':
      const baseHilo = 100;
      const responseGroups = Math.floor((responses || 0) / 5);
      return baseHilo + (responseGroups * 50);

    case 'rol':
      const baseRol = 250;
      const responseGroupsRol = Math.floor((responses || 0) / 5);
      return baseRol + (responseGroupsRol * 150);

    case 'encuesta':
      return 100;

    case 'collage':
      return 150;

    case 'poemas':
      return 150;

    case 'pinturas':
      return 200;

    case 'interpretacion':
      return 200;

    case 'otro':
    default:
      // Para otros tipos, dar trazos mínimos
      return 100;
  }
}

export function calculateExpressActivityTraces(albumId: string, wordCount: number): number {
  // Actividades Express tienen un cálculo específico
  const baseTraces = 50;
  const wordBonus = Math.floor(wordCount / 25) * 10; // 10 trazos cada 25 palabras
  return baseTraces + wordBonus;
}

// Función para obtener el tipo sugerido basado en palabras
export function getSuggestedType(wordCount: number): string {
  if (wordCount >= 1 && wordCount <= 100) {
    return 'microcuento';
  } else if (wordCount >= 101 && wordCount <= 200) {
    return 'drabble';
  } else if (wordCount >= 201) {
    return 'narrativa';
  }
  return 'otro';
}

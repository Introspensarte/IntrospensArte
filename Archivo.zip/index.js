
// Main entry point - delegates to the TypeScript server
import('./server/index.ts').catch(console.error);
